/* Readme.txt
						CS 6301.502 IMPLEMENTATION OF ADVANCED DATA STRUCTURES AND ALGORITHMS
						LONG PROJECT 5
GROUP 38
	RAKESH BALASUBRAMANI - rxb162130
	HARIPRIYAA MANIAN – hum160030
	RAJKUMAR PANNEER SELVAM - rxp162130
	AVINASH VENKATESH – axv165330

*/

Sample Execution:

1.Add,2.Ceiling,3.Contains,4.First,5.Floor,6.Get,7.isEmpty,8.Last,9.Print,10.Remove,11.Size
1
Enter element to add
10
true
Again??(1/0)
1
1.Add,2.Ceiling,3.Contains,4.First,5.Floor,6.Get,7.isEmpty,8.Last,9.Print,10.Remove,11.Size
1
Enter element to add
50
true
Again??(1/0)
1
1.Add,2.Ceiling,3.Contains,4.First,5.Floor,6.Get,7.isEmpty,8.Last,9.Print,10.Remove,11.Size
1
Enter element to add
30
true
Again??(1/0)
1
1.Add,2.Ceiling,3.Contains,4.First,5.Floor,6.Get,7.isEmpty,8.Last,9.Print,10.Remove,11.Size
1
Enter element to add
80
true
Again??(1/0)
1
1.Add,2.Ceiling,3.Contains,4.First,5.Floor,6.Get,7.isEmpty,8.Last,9.Print,10.Remove,11.Size
9
H  10 50 80 80 T T 
10  30 
30  50 
50  80 80 
80  T T T T 
T T T T T T T 
Again??(1/0)
1
1.Add,2.Ceiling,3.Contains,4.First,5.Floor,6.Get,7.isEmpty,8.Last,9.Print,10.Remove,11.Size
10
Enter element to be removed
50
50
Again??(1/0)
1
1.Add,2.Ceiling,3.Contains,4.First,5.Floor,6.Get,7.isEmpty,8.Last,9.Print,10.Remove,11.Size
9
H  10 80 80 80 T T 
10  30 
30  80 
80  T T T T 
T T T T T T T 
Again??(1/0)
