package cs6301.g38;

import java.util.ArrayDeque;

import cs6301.g38.Graph.Edge;
import cs6301.g38.Graph.Vertex;

/**
 * @author Avinash Venkatesh - axv165330 <br>
 * 		   Hari Priyaa - hum160030  <br>
 * 		   Rakesh Balasubramani - rxb162130 <br> 
 * 		   Raj Kumar Panneer Selvam - rxp162130
 * 
 * 
 * @Descriptiion This class implements Breadth First Search on an acyclic graph.
 *
 */
public class BFS {
	
	/**
	 * Queue used to traverse nodes in BFS
	 */
	private ArrayDeque<Vertex> traverseBFS = new ArrayDeque<Vertex>();
	/**
	 * ArrayList used to hold visited nodes in BFS
	 */
	private ArrayDeque<Vertex> visitedNodes = new ArrayDeque<Vertex>();

	
	/**
	 * Method: Implements BFS
	 * 
	 * @param root
	 *            - root node of BFS
	 * @param parentList
	 * 			  - Array used to store parent nodes with index used as the corresponding node names.
	 *           
	 * @return - last visited Vertex in BFS traversal
	 */
	
	public Vertex runBFS(Vertex root,Vertex[] parentList) {

		visitedNodes.clear();

		parentList[root.getName()] = new Vertex(-1);
		traverseBFS.offer(root);
		visitedNodes.add(root);

		while (!traverseBFS.isEmpty()) {
			Vertex node = traverseBFS.poll();

			for (Edge e : node) {
				Vertex otherEnd = e.otherEnd(node);

				if (!visitedNodes.contains(otherEnd)) {
					visitedNodes.add(otherEnd);
					traverseBFS.offer(otherEnd);
					parentList[otherEnd.getName()] = node;
				}

			}
		}

		return visitedNodes.peekLast();
	}

}
