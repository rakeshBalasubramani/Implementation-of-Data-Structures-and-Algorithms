package cs6301.g38;

import java.util.LinkedList;
import java.util.Scanner;

import cs6301.g38.Graph.Vertex;

/**
 * @author Avinash Venkatesh - axv165330 <br> 
 * 		   Hari Priyaa - hum160030  <br>
 * 		   Rakesh Balasubramani - rxb162130 <br> 
 * 		   Raj Kumar Panneer Selvam - rxp162130 
 * 
 * 
 * @Description This class is used to find the diameter of the given graph
 *               using BFS, provided the graph is acyclic.
 *
 */
public class Diameter {

	/**
	 * Array used to store parent nodes with index used as the corresponding node
	 * names.
	 */
	private static Vertex[] parentList;

	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		Graph g = Graph.readGraph(in);
		System.out.print("Diameter Path : ");
		LinkedList<Vertex> diameterPath = diameter(g);
		for(int i=0;i<diameterPath.size();i++)
		{
			System.out.print(diameterPath.get(i));
			if(i+1<diameterPath.size())
				System.out.print(" --> ");
		}

	}

	/**
	 * Method: Used to find the diameter of the given graph.
	 * 
	 * @param g
	 *            : Given graph
	 * @return : Returns diameter path
	 */
	static LinkedList<Graph.Vertex> diameter(Graph g) {
		parentList = new Vertex[g.size()];
		BFS bfs = new BFS();
		Vertex end = bfs.runBFS(g.getVertex(1), parentList); // First BFS to get the node at
															// maximum distance from the given node
	
		Vertex end2 = bfs.runBFS(end, parentList); // Second BFS to get the diameter in the
												  // graph

		return getDiameterPath(end2, end);

	}

	/**
	 * Method: Used to get the diameter path
	 * 
	 * @param tail
	 *            :Ending node in the diameter path
	 * @param head
	 *            :Starting node in the diameter path
	 * @return :Returns the path of the diameter.
	 */
	static LinkedList<Vertex> getDiameterPath(Vertex tail, Vertex head) {

		LinkedList<Vertex> diameterPath = new LinkedList<Vertex>();

		diameterPath.add(tail);

		while (tail != head) {
			tail = parentList[tail.getName()];
			diameterPath.add(tail);

		}

		return diameterPath;

	}
}
