package cs6301.g38;

/**
 * @author Rajkumar PanneerSelvam - rxp162130 <br>
 *         Avinash Venkatesh - axv165330 <br>
 *         Rakesh Balasubramani - rxb162130 <br>
 *         HariPriyaa Manian - hum160030
 * 
 * @Description Sort the generic array elements using Insertion Sort Algorithm.
 */
public class InsertionSort {

	/**
	 * Generic array implementation for Insertion sort. 
	 * 
	 * @param arr
	 *            -array to be sorted
	 */
	public static <T extends Comparable<? super T>> void insertionSort(T[] arr) {
		int size = arr.length;
		for (int i = 1; i < size; i++) {
			T key = arr[i];
			int j = i - 1;

			// Compare arr element with key and place the elements in correct
			// position
			while (j >= 0 && arr[j].compareTo(key) == 1) {
				arr[j + 1] = arr[j];
				j = j - 1;
			}
			arr[j + 1] = key;
		}

	}

}
