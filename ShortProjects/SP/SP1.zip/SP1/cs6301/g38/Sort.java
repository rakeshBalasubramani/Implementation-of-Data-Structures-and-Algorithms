package cs6301.g38;

import java.util.Scanner;

/**
 * @author Rajkumar PanneerSelvam - rxp162130 <br>
 *         Avinash Venkatesh - axv165330 <br>
 *         Rakesh Balasubramani - rxb162130 <br>
 *         HariPriyaa Manian - hum160030
 * 
 * @Description Driver code used to check the performance of MergeSort-Generic Array Implementation,
 *              MergeSort- Primitive int Array Implementation and InsertionSort- Generic Array Implementation in
 *              terms of time and memory used.
 */

public class Sort {

	/**
	 * Size in millions
	 */
	private static int size = 1000000;

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("Enter the size in millions:");
		int arrSize = s.nextInt(); 
		arrSize = arrSize * size;
		int[] arr = new int[arrSize];
		int[] tmp = new int[arrSize];
		Integer[] iarr = new Integer[arrSize];
		Integer[] marr = new Integer[arrSize];
		Integer[] tmp1 = new Integer[arrSize];
		Timer t = new Timer();

		// Populating the array with random elements
		for (int i = 0; i < arrSize; i++) {
			arr[i] = (int) (Math.random() * arrSize);
			tmp[i] = arr[i];
		}

		// Populating the elements to the Integer arrays
		for (int i = 0; i < arrSize; i++) {
			marr[i] = new Integer(arr[i]);
			iarr[i] = new Integer(arr[i]);
			tmp1[i] = new Integer(arr[i]);
		}

		System.out.println("Merge Sort-- Primitive int Array:");
		t.start(); // start timer
		MergeSort.mergeSort(arr, tmp);
		System.out.println(t.end()); // end timer
		System.out.println();

		System.out.println("Merge Sort-- Generic Array:");
		t.start();
		MergeSort.mergeSort(marr, tmp1);
		System.out.println(t.end());
		System.out.println();

		System.out.println("Insertion Sort-- Generic Array:");
		t.start();
		InsertionSort.insertionSort(iarr);
		System.out.println(t.end());

		s.close();
	}
}