﻿Readme.txt
CS 6301.502. IMPLEMENTATION OF ADVANCED DATA STRUCTURES AND ALGORITHMS
                                SHORT PROJECT 3
--------------------------------------------------------------------------------------------------------------------------------
GROUP 38
        RAKESH BALASUBRAMANI - rxb162130
        HARIPRIYAA MANIAN – hum160030
        RAJKUMAR PANNEER SELVAM - rxp162130
        AVINASH VENKATESH – axv165330
--------------------------------------------------------------------------------------------------------------------------------
Problem 1: Topological order of a given graph.


Files :
1. Topological Order.java


Input:
        Graph
Output:
        Topological order of the graph if the graph is a DAG else return null.


Sample Execution:
        
   11 17
1 4 1
1 3 1
1 2 1
2 6 1
2 7 1
3 5 1
3 6 1
4 6 1
4 9 1
5 10 1
5 8 1
6 8 1
7 10 1
8 11 1
9 11 1
10 11 1
1 1 1
Topological Order for algorithm 1 : null
Topological Order for algorithm 2 : null
--------------------------------------------------------------
11 16
1 4 1
1 3 1
1 2 1
2 6 1
2 7 1
3 5 1
3 6 1
4 6 1
4 9 1
5 10 1
5 8 1
6 8 1
7 10 1
8 11 1
9 11 1
10 11 1
Topological Order for algorithm 1 : [1, 4, 3, 2, 9, 5, 6, 7, 8, 10, 11]
Topological Order for algorithm 2 : [1, 2, 7, 3, 5, 10, 4, 9, 6, 8, 11]
------------------------------------------------------------------------------------------------------------------------
Problem 2 : Strongly Connected Components of a Directed Graph
Files:
        SCC.java
Input:
        Graph
Output:
        Number of strongly connected components of the graph .
Sample Execution:
11 17
1 11 1 
11 4 1 
11 6 1
11 3 1
9 11 1
4 9 1
4 1 1
5 4 1 
5 8 1
5 7 1
2 7 1
8 2 1
2 3 1
3 10 1
6 3 1
10 6 1
7 8 1
Vertex: 1 Component no: 3
Vertex: 2 Component no: 2
Vertex: 3 Component no: 4
Vertex: 4 Component no: 3
Vertex: 5 Component no: 1
Vertex: 6 Component no: 4
Vertex: 7 Component no: 2
Vertex: 8 Component no: 2
Vertex: 9 Component no: 3
Vertex: 10 Component no: 4
Vertex: 11 Component no: 3
Input graph has 4 strongly connected components.


----------------------------------------------------------------------


11 16
1 4 1
1 3 1
1 2 1
2 6 1
2 7 1
3 5 1
3 6 1
4 6 1
4 9 1
5 10 1
5 8 1
6 8 1
7 10 1
8 11 1
9 11 1
10 11 1


Vertex: 1 Component no: 1
Vertex: 2 Component no: 2
Vertex: 3 Component no: 4
Vertex: 4 Component no: 7
Vertex: 5 Component no: 5
Vertex: 6 Component no: 9
Vertex: 7 Component no: 3
Vertex: 8 Component no: 10
Vertex: 9 Component no: 8
Vertex: 10 Component no: 6
Vertex: 11 Component no: 11
Input graph has 11 strongly connected components.


---------------------------------------------------------------------------------------------------------------------------


Problem 4:  Check whether given directed graph is a Directed Cyclic Graph


Files: DirectedAcyclicGraph.java


Input: Graph


Output: True if the graph is DAG else not a DAG.


Sample Execution:


11 16
1 4 1
1 3 1
1 2 1
2 6 1
2 7 1
3 5 1
3 6 1
4 6 1
4 9 1
5 10 1
5 8 1
6 8 1
7 10 1
8 11 1
9 11 1
10 11 1
Given directed graph is a DAG
---------------------------------------------


11 17
1 4 1
1 3 1
1 2 1
2 6 1
2 7 1
3 5 1
3 6 1
4 6 1
4 9 1
5 10 1
5 8 1
6 8 1
7 10 1
8 11 1
9 11 1
10 11 1
1 1 1
Given directed graph has cycles
--------------------------------------------------------------------------------------------------------------------------------