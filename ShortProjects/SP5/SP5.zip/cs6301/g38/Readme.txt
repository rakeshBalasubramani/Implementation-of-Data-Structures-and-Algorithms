/* Readme.txt
CS 6301.502. IMPLEMENTATION OF ADVANCED DATA STRUCTURES AND ALGORITHMS
Short Project 5

GROUP 38
	RAKESH BALASUBRAMANI - rxb162130
	HARIPRIYAA MANIAN – hum160030
	RAJKUMAR PANNEER SELVAM - rxp162130
	AVINASH VENKATESH – axv165330

*/



Problem 1:

Files included:
	1- QuickSortPartition.java (driver class)
	2-  Timer.java
	3-  QuickSort.java (For Partition 1)
Input for Sort.java:
	Size of the array to be sorted

Output:
	Time taken for different versions of partition of QuickSort

Sample Execution of QuickSortPartition.java:
	Enter the array size 
1000000
Quick Sort - Arrays with distinct elements 
Partition 1
Time: 301 msec.
Memory: 99 MB / 237 MB.

Partition 2
Time: 172 msec.
Memory: 151 MB / 237 MB.

Quick Sort on randomly shuffled elements 
Partition 1
Time: 506 msec.
Memory: 144 MB / 330 MB.

Partition 2
Time: 318 msec.
Memory: 198 MB / 330 MB.

Quick Sort on arrays with elements in descending order 
Partition 1
Time: 274 msec.
Memory: 66 MB / 392 MB.

Partition 2
Time: 150 msec.
Memory: 120 MB / 392 MB.

========================================================================

Problem 2:

Files included:
	1- QuickSort.java (dual-pivot and normal Quick sort)
	2- Timer.java
	3- Sort.java (Driver class)

Input for Sort.java:
	Size of the array to be sorted in millions.
Output:
	Time taken and memory occupied for Quick Sort algorithm with different partition methods for the input array.
	

Sample Execution of Sort.java:

Enter the array size in millions
10

Quick Sort with single pivot partition for distinct values:
Time: 1966 msec.
Memory: 530 MB / 793 MB.

Quick Sort with dual pivot partition for distinct values:
Time: 2183 msec.
Memory: 473 MB / 829 MB.

Quick Sort with single pivot partition for duplicate values:
Time: 6224 msec.
Memory: 541 MB / 1027 MB.

Quick Sort with dual pivot partition for duplicate values:
Time: 5818 msec.
Memory: 601 MB / 1032 MB.


========================================================================

Problem 3:

Files included:
	1- PriorityQueueSelection.java (contains both minHeap and maxHeap)
	2- LinearTimeSelection.java 
	3- QuickSort.java ( For partition method)
	4- Timer.java
	5- SelectionComparison.java (Driver class)

Input for SelectionComparison.java:
	Size of the array to be sorted in millions and number of largest elements needed. (K)

Output:
	Time taken and memory occupied for various selection algorithm for the input array.
	

Sample Execution of SelectionComparison.java:

Enter the array size in millions
12
Enter the value of k :
10000

----------------------------------
Selection using Max heap
Time: 407 msec.
Memory: 275 MB / 378 MB.

----------------------------------
Selection using Min heap
Time: 297 msec.
Memory: 275 MB / 378 MB.

----------------------------------
Linear time selection
Time: 94 msec.
Memory: 275 MB / 378 MB.

========================================================================

Problem 4:

Files included:
	1- MergeSort.java
	2- MergeSortvsQuickSort.java 
	3- QuickSort.java 
	4- Timer.java

Input for Sort.java:
	Size of the array to be sorted

Output:
	Time taken and memory occupied for various size of input array.
	

Sample Execution of MergeSortvsQuickSort.java:
	Enter the array size in thousands
100
Merge Sort For Distinct values : Time: 56124 msec.
Memory: 10 MB / 121 MB.
Quick Sort For Distinct values : Time: 68 msec.
Memory: 14 MB / 121 MB.
Merge Sort For Duplicate values : Time: 35684 msec.
Memory: 17 MB / 121 MB.
Quick Sort For Duplicate values : Time: 40 msec.
Memory: 22 MB / 121 MB.




