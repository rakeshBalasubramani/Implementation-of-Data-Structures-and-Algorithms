// Ver 1.0:  Index interface

package cs6301.g00;
public interface Index {
    public void putIndex(int index);
    public int getIndex();
}

