// Ver 1.0:  Index interface

package cs6301.g38;
public interface Index {
    public void putIndex(int index);
    public int getIndex();
}

