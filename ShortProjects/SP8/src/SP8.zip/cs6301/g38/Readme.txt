/* Readme.txt
CS 6301.502. IMPLEMENTATION OF ADVANCED DATA STRUCTURES AND ALGORITHMS
Short Project 8

GROUP 38
	RAKESH BALASUBRAMANI - rxb162130
	HARIPRIYAA MANIAN – hum160030
	RAJKUMAR PANNEER SELVAM - rxp162130
	AVINASH VENKATESH – axv165330

*/
------------------------------------------------------------------------------------------------------------------------------
Question 1 to 5

Files Included :
	ShortestPath.java
	
	ArrayIterator.java
	BinaryHeap.java
	Graph.java
	Index.java
	IndexedHeap.java
	TopologicalOrder.java
	
Sample Executions:

Execution 1:

	5 5
	1 2 1
	1 3 1
	3 4 1
	1 4 1
	3 5 1
	Given graph has same positive edge weights...
	Running BFS...
	----------------BFS Shortest Path---------------- 
	Quueue:1
	Quueue:2
	Quueue:3
	Quueue:4
	Quueue:5
	Distance from the source vertex
	Vertex: 1  Distance :0
	Vertex: 2  Distance :1
	Vertex: 3  Distance :1
	Vertex: 4  Distance :1
	Vertex: 5  Distance :2
	
Execution 2:

	5 5
	1 2 5
	1 3 2
	3 4 1
	1 4 6
	3 5 5
	Given directed graph is a DAG...
	running DAG shortest path... 

	-------------DAG Shortest Path---------------
	Distance from the source vertex
	Vertex: 1  Distance :0
	Vertex: 2  Distance :5
	Vertex: 3  Distance :2
	Vertex: 4  Distance :3
	Vertex: 5  Distance :7

Execution 3:

	5 7
	1 5 8
	1 4 7
	1 3 6
	4 3 3
	3 5 6
	5 3 2
	5 2 1
	Graph has no negative edge weights...
	Running Dijkstra's shortest path...

	------------Dijkstra's Shortest Path-------------------
	Distance from the source vertex
	Vertex: 1  Distance :0
	Vertex: 2  Distance :9
	Vertex: 3  Distance :6
	Vertex: 4  Distance :7
	Vertex: 5  Distance :8
	
------------------------------------------------------------------------------------------------------




